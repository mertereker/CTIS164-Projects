INSTALLING GLUT LIBRARY :

If you have Visual Studio 2013, its default folder : C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC

STEPS:
------------------------------------
1. Copy all header files:
   a) Create a "GL" folder under "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\include"
   b) Copy all files in "include" folder of this zip file into "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\include\GL"
2. Copy all files in "lib" folder into "C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\lib" folder.
3. Copy all files in "dll" folder into "C:\windows\" or/and "C:\windows\system32\"  folder.
